
from django.http import HttpResponse
from django.shortcuts import render
#from django.views.decorators.csrf import csrf_exempt


def home(request):
    a=10
    b=20
    c=a+b

    mks=[60,45,65,85,78,95]

    empd={"eno":1001, "ename":"Prakash", "esal":20000.56}
    return render(request, 'home.html',{"a":a, "b":b, "c":c,"mks":mks,"empd":empd})
    
    #return HttpResponse("<h1> /or home/ url invoked</h1>"+urlRoute)

def about(request):
    #print(request)
    #print(request.method)
    #print(request.path)

    emp=[{"eno":1001,"enm":"Prakash Rakeshiya","esal":20000.35},{"eno":1002,"enm":"RAM","esal":20050.85},
        {"eno":1003,"enm":"Baldev","esal":205656.15},{"eno":1004,"enm":"Rohan","esal":555000.25}]
    return render(request, 'about.html')
def contact(request):
    return render(request, 'contact.html')
#@csrf_exempt
def service(request):
    return render(request, 'service.html')
    """
    if request.method== "GET":
        msg="<h1> service/ url invoked & method GET </h1>"
    elif request.method=="POST":
        msg="<h1> service/ url invoked & method POST </h1>"
    elif request.method=="PUT":
        msg="<h1> service/ url invoked & method PUT </h1>"
    elif request.method=="DELETE":
        msg="<h1> service/ url invoked & method DELETE </h1>"
    else :
        msg="<h1> service/ url invoked & method Anonymous  </h1>"
        """
    #return HttpResponse(msg+urlRoute)

def register(request):
    return render(request, 'register.html')

def login(request):
   return render(request, 'login.html')
   