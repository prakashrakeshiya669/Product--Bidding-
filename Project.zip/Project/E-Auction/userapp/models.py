from django.db import models

# Create your models here.
class Payment(models.Model):
    trsnid=models.AutoField(primary_key=True)
    uid=models.CharField(max_length=150)
    amt=models.IntegerField()
    info=models.CharField(max_length=200)