from django.shortcuts import render,redirect
from django.http import HttpResponse 

from myadmin import models as myadmin_models
from myapp import models as myapp_models
from . import models  
import time


#middleware to check session for User routes
def sessioncheckuserapp_middleware(get_response):
	def middleware(request):
		if request.path=='/user/' or request.path=='/user/funds/' or request.path=='/user/payment/' or request.path=='/user/success/' or request.path=='/user/cancel/' or request.path=='/user/cpuser/' or request.path=='/user/epuser/':
			if request.session['sesunm']==None or request.session['sesrole']!="user":
				response = redirect('/login/')
			else:
				response = get_response(request)
		else:
			response = get_response(request)		
		return response	
	return middleware


# Create your views here.

def userhome(request):
    return render(request, 'userhome.html',{"sesunm":request.session["sesunm"]})

def cpuser(request):
     if request.method=="GET":
      return render(request, 'cpuser.html',{"sesunm":request.session["sesunm"]})
     else:
          opassword=request.POST.get("opassword")
          npassword=request.POST.get("npassword")
          cnpassword=request.POST.get("cnpassword")
          sesunm=request.session["sesunm"]

          userDetails=myapp_models.Register.objects.filter(email=sesunm,password=opassword)
          if len(userDetails)>0:
           if npassword==cnpassword:
               myapp_models.Register.objects.filter(email=sesunm).update(password=cnpassword)
               msg="Password Changed Successfully...!!"
           else:
               msg="New Password and Confirm New Password Not Match"
              
          else:
              msg="Old password is Missmatch"
          return render(request, 'cpuser.html',{"sesunm":request.session["sesunm"],"output":msg})
        
         
def epuser(request):
     if request.method=="GET":
      userDetails=myapp_models.Register.objects.filter(email=request.session["sesunm"])
      return render(request, 'epuser.html',{"sesunm":request.session["sesunm"],"userDetails": userDetails[0]})

     else:
        #to recive data from UI
        name=request.POST.get("name")
        email=request.POST.get("email")
        mobile=request.POST.get("mobile")
        address=request.POST.get("address")
        city=request.POST.get("city")
        gender=request.POST.get("gender")

        #Update record in data base table
        myapp_models.Register.objects.filter(email=request.session["sesunm"]).update(name=name,mobile=mobile,address=address, city=city, gender=gender)
        return redirect("/user/epuser/",{"output":"Update is successfully"})
def funds(request):
    paypalURL="https://www.sandbox.paypal.com/cgi-bin/webscr"
    paypalID="sb-hb0uy26638130@business.example.com"
    amt=100
    # to Personal Account ="sb-jqj43v26976395@personal.example.com"
    return render(request, 'funds.html',{"paypalURL":paypalURL,"paypalID":paypalID,"amt":amt,"sesunm":request.session["sesunm"]})
 
def payment(request):
     print(request.session["sesunm"])
     uid=request.GET.get("uid")
     amt=request.GET.get("amt")
     p=models.Payment(uid=uid,amt=int(amt),info=time.asctime())
     p.save()
     return redirect("/user/success/")


def success(request):
     return render(request, 'success.html',{"sesunm":request.session["sesunm"]})

def cancel(request):
      return render(request, 'cancel.html',{"sesunm":request.session["sesunm"]})


def searchcat(request):
    clist=myadmin_models.Category.objects.all()
    return render(request, 'searchcat.html',{"clist":clist,"sesunm":request.session["sesunm"]})


def searchsubcat(request):
    catname=request.GET.get("catname")
    clist=myadmin_models.Category.objects.all()
    sclist=myadmin_models.SubCategory.objects.filter(catname=catname)
    return render(request, 'searchsubcat.html',{"catname":catname,"sclist":sclist,"clist":clist,"sesunm":request.session["sesunm"]})


def searchproduct(request):
    scname=request.GET.get("scname")
    plist=myadmin_models.Product.objects.filter(subcatname=scname)
    return render(request, 'searchproduct.html',{"plist":plist,"sesunm":request.session["sesunm"]})



def bidstatus(request):
    pid=int(request.GET.get("pid"))
    pDetails=myadmin_models.Product.objects.filter(pid=pid)
    #print(pDetails[0].info)
    Diftime=time.time()-int(pDetails[0].info)
    return render(request, 'searchproduct.html',{"plist":plist,"sesunm":request.session["sesunm"]})

