from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage

from myapp import models as myapp_models
from . import models
import time



#middleware to check session for admin routes
def sessioncheckmyadmin_middleware(get_response):
	def middleware(request):
		if request.path=='/myadmin/' or request.path=='/myadmin/manageusers/' or request.path=='/myadmin/manageusersstatus/' :
			if request.session['sesunm']==None or request.session['sesrole']!="admin":
				response = redirect('/login/')
			else:
				response = get_response(request)
		else:
			response = get_response(request)		
		return response	
	return middleware


# Create your views here.
def adminhome(request):
    #print(request.session["sesunm"])
    #print(request.session["sesrole"])
    #return HttpResponse("<>This is Admin Pannel</")
    return render(request,'adminhome.html',{"sesunm":request.session["sesunm"]})

def manageusers(request):
    userDetails=myapp_models.Register.objects.filter(role="user")
    return render(request, 'manageusers.html', {"userDetails":userDetails, "sesunm":request.session["sesunm"]})

def manageusersstatus(request):
    regid=int(request.GET.get("regid"))
    status=int(request.GET.get("status"))

    if status==1:
        myapp_models.Register.objects.filter(regid=regid).update(status=status)
    elif status==0:
        myapp_models.Register.objects.filter(regid=regid).update(status=status)
    else:
        myapp_models.Register.objects.filter(regid=regid).delete()
    return redirect("/myadmin/manageusers/")
    

def addcategory(request):
    if request.method=="GET":
     return render(request,'addcategory.html',{"sesunm":request.session["sesunm"],"output": " "})
    else:
     catname=request.POST.get("catname")
     caticon=request.FILES["caticon"]
     fs=FileSystemStorage()
     filename=fs.save(caticon.name,caticon)

     c=models.Category(catname=catname,caticonname=filename)
     c.save()
     return render(request,'addcategory.html',{"sesunm":request.session["sesunm"],"output":"Category Added is Successfull...!!"})


def addsubcategory(request):
    clist=models.Category.objects.all()
    if request.method=="GET":
     return render(request,'addsubcategory.html',{"sesunm":request.session["sesunm"],"output": " ","clist":clist})
    else:
     catname=request.POST.get("catname")
     subcatname=request.POST.get("subcatname")
     subcaticon=request.FILES["subcaticon"]
     fs=FileSystemStorage()
     filename=fs.save(subcaticon.name,subcaticon)

     sc=models.SubCategory(catname=catname,subcatname=subcatname,subcaticonname=filename)
     sc.save()
     return render(request,'addsubcategory.html',{"sesunm":request.session["sesunm"],"output":"SubCategory Added is Successfull...!!","clist":clist})
    

def addproduct(request):
     sclist=models.SubCategory.objects.all()
     if request.method=="GET":
      return render(request,'addproduct.html',{"sesunm":request.session["sesunm"],"sclist":sclist,"output": " "})
     else:
      ptitle=request.POST.get("ptitle")
      subcatname=request.POST.get("subcatname")
      pdesc=request.POST.get("pdesc")
      pbprice=request.POST.get("pbprice")
      picon=request.FILES["picon"]
      fs=FileSystemStorage()
      filename=fs.save(picon.name,picon)

      p=models.Product(ptitle=ptitle,subcatname=subcatname,pdesc=pdesc,pbprice=pbprice,piconname=filename,info=time.time())
      p.save()
      return render(request,'addproduct.html',{"sesunm":request.session["sesunm"],"sclist":sclist,"output": "Product Added Successfulll.....!!!"})
   

