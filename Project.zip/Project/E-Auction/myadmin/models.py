from django.db import models

# Create your models here.

class Category(models.Model):
    catid=models.AutoField(primary_key=True)
    catname=models.CharField(max_length=200,unique=True)
    caticonname=models.CharField(max_length=100)


class SubCategory(models.Model):
    subcatid=models.AutoField(primary_key=True)
    catname=models.CharField(max_length=200)
    subcatname=models.CharField(max_length=200,unique=True)
    subcaticonname=models.CharField(max_length=150)


class Product(models.Model):
    pid=models.AutoField(primary_key=True)
    ptitle=models.CharField(max_length=200)
    subcatname=models.CharField(max_length=200)
    pdesc=models.CharField(max_length=500)
    pbprice=models.IntegerField()
    piconname=models.CharField(max_length=150)
    info=models.IntegerField()
